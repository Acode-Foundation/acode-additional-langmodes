# Changelog

## 1.1.0

- Add Zig and ZON language support.
- Add missing CodeMirror community modes for BibTeX, Elixir, GolfScript,
  GraphQL, Graphviz DOT, HCL, J, Janet, Pkl, Svelte, and WGSL.
- Reuse Acode's CodeMirror runtime modules across community packages.

## 1.0.0

- Add AutoHotkey v1/v2 language support.
