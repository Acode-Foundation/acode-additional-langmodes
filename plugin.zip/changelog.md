# Changelog

## v1.2.2

- Added an Erlang mode (`.erl`, `.hrl`, `.escript`, `.app.src`) with a full
  Lezer parser, highlighting, indentation, folding, keyword bracket matching,
  and completions for keywords, BIFs, macros, attributes, and OTP modules.

## v1.2.1

- Added a Lezer grammar (`.grammar`) mode with a full Lezer parser,
  highlighting, indentation, folding, and context-aware completions.

## v1.2.0

- Added Lezer-based C, Clojure, Kotlin, LaTeX, Lua, and Swift modes, used by
  default for their file extensions.
- Added Ada, Handlebars, Mustache, and Nix modes.

## v1.1.8

- Added Jsonl mode

## v1.1.7

- Added a Solidity mode with a full Lezer parser, highlighting, indentation, folding, and basic completions.

## v1.1.6

- Prefer Acode's shared @lezer/lr when available, falling back to a bundled copy for older Acode versions.

## v1.1.5

- Added a Makefile mode 

## v1.1.4

- Added an enhanced YAML/YML mode with structural parsing, richer scalar highlighting, indentation, and folding.

## 1.1.3

- Added git commit message mode (`^COMMIT_EDITMSG`, `^commit_editmsg`)

## 1.1.2

- Added gleam language support

## 1.1.1

- Added gitattributes modes and fixed indentation issue of ejs mode

## 1.1.0

- Added new modes:
    - Jsonc
    - Assembly
    - ASCIIDoc
    - Ejs

## 1.0.1

- fixed bibtex mode issue

## 1.0.0

- Add AutoHotkey v1/v2 language support.
- Add Zig and ZON language support.
- Add Git ignore language support.
- Add missing CodeMirror community modes for BibTeX, Elixir, GolfScript,
  GraphQL, Graphviz DOT, HCL, J, Janet, Pkl, Svelte, and WGSL.
